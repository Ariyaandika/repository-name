import React from 'react';
import { StyleSheet, View } from 'react-native';
import FriendList from './components/FriendList';

function App() {
  return (
    <View style={styles.app}>
      <FriendList />
    </View>
  );
}

const styles = StyleSheet.create({
  app: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },
});

export default App;
