import React, { useState } from 'react';
import { StyleSheet, View, Text, FlatList, Button, Image } from 'react-native';
import FriendDetail from './FriendDetail';

const friends = [
  { id: 1, name: 'ALUCARD', description: 'Rajin Belajar', image: require('./images/alu.jpg') },
  { id: 2, name: 'NANA', description: 'Teman dari SMP', image: require('./images/nana.jpeg') },
  { id: 3, name: 'Miya', description: 'Teman dari SMA', image: require('./images/miya.jpg') },
  { id: 4, name: 'Zilong', description: 'Rajin Maen Bola', image: require('./images/rpl.jpg') },
];

const FriendList = () => {
  const [selectedFriend, setSelectedFriend] = useState(null);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Daftar Teman</Text>
      <FlatList
        data={friends}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.friendItem}>
            <Image source={item.image} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.name}>{item.name}</Text>
              <Button title="Lihat Detail" onPress={() => setSelectedFriend(item)} />
            </View>
          </View>
        )}
      />
      {selectedFriend && <FriendDetail friend={selectedFriend} />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
  },
  friendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default FriendList;
